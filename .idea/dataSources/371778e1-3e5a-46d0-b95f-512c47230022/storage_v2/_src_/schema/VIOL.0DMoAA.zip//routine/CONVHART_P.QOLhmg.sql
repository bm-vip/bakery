create FUNCTION CONVHART_P(HRF IN varchar2) RETURN varchar2 IS
BEGIN
  IF HRF = '01' THEN
    ---ALF
    RETURN '???';
  ELSIF HRF = '02' THEN
    ---B
    RETURN '?';
  ELSIF HRF = '03' THEN
    ---T
    RETURN '?';
  ELSIF HRF = '04' THEN
    ---J
    RETURN '?';
  ELSIF HRF = '05' THEN
    ---D
    RETURN '?';
  ELSIF HRF = '06' THEN
    ---C
    RETURN '?';
  ELSIF HRF = '07' THEN
    ---S
    RETURN '?';
  ELSIF HRF = '08' THEN
    ---TA
    RETURN '?';
  ELSIF HRF = '09' THEN
    ---AYN
    RETURN '?';
  ELSIF HRF = '10' THEN
    ---GH
    RETURN '?';
  ELSIF HRF = '11' THEN
    ---L
    RETURN '?';
  ELSIF HRF = '12' THEN
    ---M
    RETURN '?';
  ELSIF HRF = '13' THEN
    ---N
    RETURN '?';
  ELSIF HRF = '14' THEN
    ----V
    RETURN '?';
  ELSIF HRF = '15' THEN
    ----H
    RETURN '?';
  ELSIF HRF = '16' THEN
    ----Y
    RETURN '?';
  ELSIF HRF = '17' THEN
    ----R
    RETURN '?';
  ELSIF HRF = '18' THEN
    ----K
    RETURN '?';
  ELSIF HRF = '19' THEN
    ----ZH
    RETURN '?';
  ELSIF HRF = '20' THEN
    ---P
    RETURN '?';
  ELSIF HRF = '22' THEN
    ---G
    RETURN '?';
  ELSIF HRF = '23' THEN
    ---F
    RETURN '?';
  ELSIF HRF = '24' THEN
    ---SH
    RETURN '?';
  ELSIF HRF = '25' THEN
    ---
    RETURN '?';
  ELSIF HRF = '26' THEN
    ---Z
    RETURN '?';
  ELSIF HRF = '33' THEN
    RETURN 'D';
  ELSIF HRF = '34' THEN
    RETURN 'S';
  ELSE
    RETURN '00000';
  END IF;
END;
/

