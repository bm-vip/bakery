create package dbpk_report is

  ------------getall_recive_info
  procedure getall_recive_info(mm          out sys_refcursor,
                               companycode number,
                               cameracode  number,
                               actioncode  number,
                               begindate   varchar2,
                               enddate     varchar2);

  ----------get_countwarning_byusercode                               
  procedure get_countwarning_byusercode(mm        out number,
                                        usercode  number,
                                        begindate varchar2,
                                        enddate   varchar2);

end dbpk_report;
/

