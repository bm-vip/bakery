create package body dbpk_report is

  ------------grtall_recive_info
  procedure getall_recive_info(mm          out sys_refcursor,
                               companycode number,
                               cameracode  number,
                               actioncode  number,
                               begindate   varchar2,
                               enddate     varchar2) is
    wher      varchar2(4000);
    acttypeid number;
    compid    number;
  begin
  
    if cameracode is not null then
      wher := wher || ' and w.camera_code =' || cameracode;
    end if;
  
    if begindate is not null then
      wher := wher || ' and trunc(l.register_date)>=trunc(to_date(' || '''' ||
              begindate || '''' || ',' || '''' || 'yyyy/mm/dd' || '''' || ',' || '''' ||
              'nls_calendar=persian' || '''' || '))';
    else
      wher := wher || ' and trunc(l.register_date)= trunc(sysdate)';
    end if;
  
    if enddate is not null then
      wher := wher || ' and trunc(l.register_date)<=trunc(to_date(' || '''' ||
              enddate || '''' || ',' || '''' || 'yyyy/mm/dd' || '''' || ',' || '''' ||
              'nls_calendar=persian' || '''' || '))';
    end if;
  
    if actioncode is not null then
      select e.id
        into acttypeid
        from tbl_fps_action_type e
       where e.action_code = actioncode;
      wher := wher || ' and a.id =' || acttypeid;
    end if;
    if companycode is not null then
    
      select c.id
        into compid
        from tbl_fps_company c
       where c.company_code = companycode;
    
      wher := wher || ' and c.id =' || compid;
    
    end if;
    open mm for 'select count(1) cnt,
           w.camera_code,
           c.company_name,
           a.action_type,
           to_char(l.register_date, ''yy/mm/dd'', ''nls_calendar=persian'') register_date
      from tbl_fps_information_warning w,
           tbl_fps_info_log     l,
           tbl_fps_user         u,
           tbl_fps_company      c,
           tbl_fps_action_type  a
     where w.id = l.fk_warning_id
       and l.fk_user_id = u.id
       and l.fk_action_type_id = a.id
       and u.company_id = c.id' || wher || '
       group by   w.camera_code,
           c.company_name,
           a.action_type,
           to_char(l.register_date, ''yy/mm/dd'', ''nls_calendar=persian'')';
  
  end getall_recive_info;

  ----------get_countwarning_byusercode                               
  procedure get_countwarning_byusercode(mm        out number,
                                        usercode  number,
                                        begindate varchar2,
                                        enddate   varchar2) is
    userid number;
  begin
      begin
    select u.id
      into userid
      from tbl_fps_user u
     where u.user_code = usercode;

    select count(1)
      into mm
      from tbl_fps_information_warning t, tbl_fps_info_log l
     where t.id = l.fk_warning_id
       and l.fk_user_id = userid
       and to_char(l.register_date, 'yyyy/mm/dd', 'nls_calendar=persian') >=
           begindate
       and to_char(l.register_date, 'yyyy/mm/dd', 'nls_calendar=persian') <=
           enddate;
           exception when others then
             select -1 into mm from dual;
             end;
  end get_countwarning_byusercode;

end dbpk_report;
/

