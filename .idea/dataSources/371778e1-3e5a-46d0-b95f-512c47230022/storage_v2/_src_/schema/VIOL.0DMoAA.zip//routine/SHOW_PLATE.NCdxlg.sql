create function show_plate(plate varchar2)   return varchar2 is
 pelak     varchar2(50);
begin
 if substr(plate,3,2)not in(33,34) then
  pelak:=  substr(plate,5,3) || '-' ||substr(plate,8,2)  ||  convhart_p (substr(plate,3,2))  || substr(plate,1,2) ;
  else
    pelak:=substr(plate,1,2)|| convhart_p (substr(plate,3,2)) ||  substr(plate,5,3) || '-' ||substr(plate,8,2)   ;
    end if;

  return(pelak);
end show_plate;
/

