create function convert_plakfoka_plaknaja(plak number) return varchar2 is
plate_naja varchar2(20);
  begin
    if substr(plak, 3, 2) not in (01, 03, 09, 18, 19,20,22,23,24,25,26,33,34) then
  --    select substr(plak, 3, 2) into harf from dual;
      plate_naja := '100' || substr(plak, 8, 2) || '00000000' || substr(plak,3,2) ||  substr(plak, 1,2)||     substr(plak, 5, 3) ;
    elsif substr(plak, 3, 2) = 01 then
      plate_naja := '110' || substr(plak, 8, 2) || '00000000' || '01' ||   substr(plak, 1,2)||     substr(plak, 5, 3) ;
    elsif substr(plak, 3, 2) = 03 then
      plate_naja := '120' || substr(plak, 8, 2) || '00000000' || '03' ||  substr(plak, 1,2)||     substr(plak, 5, 3) ;
    elsif substr(plak, 3, 2) = 09 then
      plate_naja := '130' || substr(plak, 8, 2) || '00000000' || '09' ||  substr(plak, 1,2)||     substr(plak, 5, 3) ;
    elsif substr(plak, 3, 2) = 18 then
      plate_naja := '370' || substr(plak, 8, 2) || '00000000' || '18' ||  substr(plak, 1,2)||     substr(plak, 5, 3) ;
    elsif substr(plak, 3, 2) = 19 then
      plate_naja := '380' || substr(plak, 8, 2) || '00000000' || '19' ||  substr(plak, 1,2)||     substr(plak, 5, 3) ;
    elsif substr(plak, 3, 2) = 20 then
      plate_naja := '420' || substr(plak, 8, 2) || '00000000' || '20' ||  substr(plak, 1,2)||     substr(plak, 5, 3) ;
      elsif substr(plak, 3, 2) = 22 then
      plate_naja := '440' || substr(plak, 8, 2) || '00000000' || '22' ||  substr(plak, 1,2)||     substr(plak, 5, 3) ;
      elsif substr(plak, 3, 2) = 23 then
      plate_naja := '470' || substr(plak, 8, 2) || '00000000' || '23' ||  substr(plak, 1,2)||     substr(plak, 5, 3) ;
      elsif substr(plak, 3, 2) = 24 then
      plate_naja := '480' || substr(plak, 8, 2) || '00000000' || '24' ||  substr(plak, 1,2)||     substr(plak, 5, 3) ;
      elsif substr(plak, 3, 2) = 25 then
      plate_naja := '490' || substr(plak, 8, 2) || '00000000' || '25' ||  substr(plak, 1,2)||     substr(plak, 5, 3) ;
      elsif substr(plak, 3, 2) = 26 then
      plate_naja := '500' || substr(plak, 8, 2) || '00000000' || '26' ||  substr(plak, 1,2)||     substr(plak, 5, 3) ;
       elsif substr(plak, 3, 2) = 33 then
      plate_naja := '450' || substr(plak, 8, 2) || '00000000' || '33' ||  substr(plak, 1,2)||     substr(plak, 5, 3) ;
       elsif substr(plak, 3, 2) = 34 then
      plate_naja := '460' || substr(plak, 8, 2) || '00000000' || '34' ||  substr(plak, 1,2)||     substr(plak, 5, 3) ;
    end if;
  return(plate_naja);
end convert_plakfoka_plaknaja;

/

