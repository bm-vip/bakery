create package body dbpk_report is

  ------------grtall_recive_info
  procedure getall_recive_info(mm          out sys_refcursor,
                               companycode number,
                               cameracode  number,
                               actioncode  number,
                               begindate   varchar2,
                               enddate     varchar2) is
    wher      varchar2(4000);
    acttypeid number;
    compid    number;
  begin
  
    if cameracode is not null then
      wher := wher || ' and w.camera_code =' || cameracode;
    end if;
  
    if begindate is not null then
      wher := wher || ' and trunc(l.register_date)>=trunc(to_date(' || '''' ||
              begindate || '''' || ',' || '''' || 'yyyy/mm/dd' || '''' || ',' || '''' ||
              'nls_calendar=persian' || '''' || '))';
    else
      wher := wher || ' and trunc(l.register_date)= trunc(sysdate)';
    end if;
  
    if enddate is not null then
      wher := wher || ' and trunc(l.register_date)<=trunc(to_date(' || '''' ||
              enddate || '''' || ',' || '''' || 'yyyy/mm/dd' || '''' || ',' || '''' ||
              'nls_calendar=persian' || '''' || '))';
    end if;
  
    if actioncode is not null then
      select e.pk_action_type_id
        into acttypeid
        from tbl_fps_action_type e
       where e.action_code = actioncode;
      wher := wher || ' and a.pk_action_type_id =' || acttypeid;
    end if;
    if companycode is not null then
    
      select c.pk_company_id
        into compid
        from tbl_fps_company c
       where c.company_code = companycode;
    
      wher := wher || ' and c.pk_company_id =' || compid;
    
    end if;
   open mm for
    'select count(1) cnt,
           w.camera_code,
           c.company_name,
           a.action_type,
           to_char(l.register_date, ''yy/mm/dd'', ''nls_calendar=persian'') register_date
      from tbl_fps_info_warning w,
           tbl_fps_info_log     l,
           tbl_fps_user         u,
           tbl_fps_company      c,
           tbl_fps_action_type  a
     where w.pk_info_warning_id = l.fk_warning_id
       and l.fk_user_id = u.pk_user_id
       and l.fk_action_type_id = a.pk_action_type_id
       and u.fk_company_id = c.pk_company_id'|| wher ||'
       group by   w.camera_code,
           c.company_name,
           a.action_type,
           to_char(l.register_date, ''yy/mm/dd'', ''nls_calendar=persian'')';
  
  end getall_recive_info;

end dbpk_report;
/

