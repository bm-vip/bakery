create function convert_plakfoka_plaknaja(plak number) return varchar2 is
plate_naja varchar2(20);
  begin
    if substr(plak, 3, 2) not in (01, 03, 09, 18, 19) then
  --    select substr(plak, 3, 2) into harf from dual;
      plate_naja := '100' || substr(plak, 8, 2) || '00000000' || substr(plak,3,2) ||
               substr(plak, 1, 2)||     substr(plak, 1, 2) ;
    elsif substr(plak, 3, 2) = 01 then
      plate_naja := '110' || substr(plak, 1, 2) || '00000000' || '01' ||
               substr(plak, 5, 5);
    elsif substr(plak, 3, 2) = 03 then
      plate_naja := '120' || substr(plak, 1, 2) || '00000000' || '03' ||
               substr(plak, 5, 5);
    elsif substr(plak, 3, 2) = 09 then
      plate_naja := '130' || substr(plak, 1, 2) || '00000000' || '09' ||
               substr(plak, 5, 5);
    elsif substr(plak, 3, 2) = 18 then
      plate_naja := '370' || substr(plak, 1, 2) || '00000000' || '18' ||
               substr(plak, 5, 5);
    elsif substr(plak, 3, 2) = 19 then
      plate_naja := '380' || substr(plak, 1, 2) || '00000000' || '19' ||
               substr(plak, 5, 5);

    end if;
  return(plate_naja);
end convert_plakfoka_plaknaja;
/

