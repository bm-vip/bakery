create package body dbpk_smtcam is
  -------------------------------add_info_warning
  procedure add_info_warning(mm                  out sys_refcursor,
                             CameraCode          number,
                             Speed_              number,
                             PlateNo             varchar2,
                             ViolationOccureDate varchar2,
                             ViolationTypeCode   number,
                             viol_add            varchar2,
                             usercode            number,
                             plateimage          blob,
                             vehicleimage1       blob,
                             vehicleimage2       blob,
                             check_type            number,
                            surveillance_cam number,
                            user_ip number ) is
    seq    number;
    userid number;
  
  begin
    begin
      select u.id
        into userid
        from tbl_fps_user u
       where u.user_code = usercode;
      select seq_image_info.nextval into seq from dual;
      insert into tbl_fps_information_warning
      values
        (seq,
        sysdate,
        400,
        null,
        null,
         CameraCode,
         check_type,
         surveillance_cam,
        PlateNo,
        PlateNo,
        Speed_,
        1,
        0,
        viol_add,
          to_date(ViolationOccureDate,
                 'yyyy/mm/dd hh24:mi:ss',
                 'nls_calendar=persian'),
        null,
        ViolationTypeCode );
    
      insert into tbl_fps_info_log
      values
        (seq_info_log.nextval,sysdate,400,null,null,user_ip, sysdate, 1, seq, userid);
      if check_type = 1 then
      
        insert into tbl_fps_info_image
        values
          (seq_image_info.nextval,
          sysdate,
          400,
          null,
          null,
          null,
           plateimage,
           vehicleimage1,
           vehicleimage2,
           seq);
           NULL;
                 elsif check_type = 2 then
        insert into tbl_fps_info_image
        values
          (seq_image_info.nextval,
          sysdate,
          400,
          null,
          null,
          vehicleimage1,
           plateimage,
           null,
           null,
           seq);
    NULL;  end if;
      commit;
      open mm for
        select 1 res,seq seq from dual;
    
    exception
      when others then
        open mm for
          select 0 res,0 seq from dual;
    end;
  
  end add_info_warning;

  --------------------get_top_infowarning
  procedure get_top_infowarning(mm          out sys_refcursor,
                                companyid number,
                                begindate   varchar2,
                                enddate     varchar2,
                                cameracode  number,
                                violcode    number) is
  
    whrr    varchar2(4000);
    /*comp_id number;*/
    cnt     number;
   /*m varchar2(4000);*/
  begin
    whrr := ' and 1 = 1 ';
  
    if begindate is not null then
      whrr := whrr || ' and mc.violation_date>=to_date(' || '''' ||
              begindate || '''' || ',' || '''' || 'yyyy/mm/dd' || '''' || ',' || '''' ||
              'nls_calendar=persian' || '''' || ')';
    else
      whrr := whrr || ' and trunc(mc.violation_date)=trunc(sysdate)';
    end if;
    if enddate is not null then
      whrr := whrr || ' and mc.violation_date<=to_date(' || '''' || enddate || '''' || ',' || '''' ||
              'yyyy/mm/dd' || '''' || ',' || '''' || 'nls_calendar=persian' || '''' || ')';
    
    end if;
  
    if violcode is not null then
      whrr := whrr || ' and mc.violation_code =' || violcode;
    end if;
  
    if cameracode is not null then
      whrr := whrr || ' and mc.camera_code =' || cameracode;
    end if;
  
    whrr := whrr || ' and rownum<2';
 /*   select y.id
      into comp_id
      from tbl_fps_company y
     where y.company_code = companycode;*/
    whrr := whrr || ' and  c.id =' || companyid;
  /* m:= 'insert into tbl_fps_temp_warning  select distinct mc.id, mc.plate_no, show_plate(mc.plate_no) plate_char, mc.camera_code,mc.violation_code, to_char(mc.violation_date,'' yyyy / mm / dd hh24 :mi :ss '','' nls_calendar = persian '') violation_date,
                  mc.violation_address, mc.speed,e.img_cnt,e.viol_type   from tbl_fps_information_warning   mc, tbl_fps_violation_type e, tbl_fps_info_log  l,tbl_fps_user   u,tbl_fps_company   c   where mc.violation_code = e.viol_code     and mc.id = l.fk_warning_id
     and mc.check_type = 1     and mc.status = 1     and l.fk_user_id = u.id     and u.company_id = c.id' || whrr;*/
    execute immediate 'delete tbl_fps_temp_warning';
    execute immediate 'insert into tbl_fps_temp_warning  select distinct mc.id, mc.plate_no, show_plate(mc.plate_no) plate_char, mc.camera_code,mc.violation_code, to_char(mc.violation_date,'' yyyy / mm / dd hh24 :mi :ss '','' nls_calendar = persian '') violation_date,
                  mc.violation_address, mc.speed,e.img_cnt,e.viol_type   from tbl_fps_information_warning   mc, tbl_fps_violation_type e, tbl_fps_info_log  l,tbl_fps_user   u,tbl_fps_company   c   where mc.violation_code = e.viol_code     and mc.id = l.fk_warning_id
     and mc.check_type = 1     and mc.status = 1     and l.fk_user_id = u.id     and u.company_id = c.id' || whrr;
    update tbl_fps_information_warning iw
       set iw.status = 2
     where iw.id in
           (select w.pk_info_warning_id from tbl_fps_temp_warning w);
    commit;
  
    select count(1) into cnt from tbl_fps_temp_warning;
  
    if cnt > 0 then
      open mm for
        select g.pk_info_warning_id,
               g.plate_no,
               g.plate_char,
               g.camera_code,
               g.violation_code,
               g.violation_date,
               g.violation_address,
               g.speed,
               g.img_cnt,
               g.violation_type
          from tbl_fps_temp_warning g;
    else
      open mm for
        select 0 pk_info_warning_id,
               0 plate_no,
               0 plate_char,
               0 camera_code,
               0 violation_code,
               0 violation_date,
               0 violation_address,
               0 speed,
               0 img_cnt,
               0 violation_type
          from dual;
    end if;
  
  end get_top_infowarning;

  -----------------get_image_infowar
  procedure get_image_infowar(mm out sys_refcursor, infowarid number) is
  begin
    open mm for
      select e.plate_image, e.vehicle_image1, e.vehicle_image2, 1 id
        from tbl_fps_info_image e
       where e.fk_info_warning_id = infowarid;
  end get_image_infowar;
  ------------------edit_info_warning
  procedure edit_info_warning(mm         out sys_refcursor,
                              infowarid  number,
                              status     number,
                              userid     number,
                              plateno    varchar2,
                              ip_        varchar2,
                              contrad_id number,
                              actiocode  number) is
    actid number;
  begin
    if status in (3, 5) then
      begin
        update tbl_fps_information_warning c
           set c.plate_new = plateno, c.status = status
         where c.id = infowarid;
        select a.id
          into actid
          from tbl_fps_action_type a
         where a.action_code = actiocode;
        insert into tbl_fps_info_log
        values
          (seq_info_log.nextval,sysdate,400,null,null, ip_ , sysdate, actid, infowarid,userid );
      exception
        when others then
          open mm for
            select 0 res from dual;
      end;
    else
      begin
        update tbl_fps_information_warning  c
           set c.plate_new               = plateno,
               c.status                  = 4,
               c.fk_contradictoriness_id = contrad_id
         where c.id = infowarid;
       
       insert into tbl_fps_info_log
        values
          (seq_info_log.nextval,sysdate,400,null,null, ip_ , sysdate, actid, infowarid,userid );
      exception
        when others then
          open mm for
            select 0 res from dual;
      end;
    end if;
    commit;
    open mm for
      select 1 res from dual;
  end edit_info_warning;

  -----------------getall_CONTRADICTORINESS
  procedure getall_CONTRADICTORINESS(mm out sys_refcursor) is
  begin
    open mm for
      select t.id,
             t.contradictoriness_code,
             t.contradictoriness_type
        from tbl_fps_contradictoriness t
       order by contradictoriness_code;
  end getall_CONTRADICTORINESS;

  ----------------getall_infowar_bysend
  procedure getall_infowar_bysend(mm          out sys_refcursor,
                                  begindate   varchar2,
                                  enddate     varchar2,
                                  companycode number,
                                  cameracode  number) is
    whrr    varchar2(4000);
    comp_id number;
  begin
    whrr := ' and 1 = 1 ';
  
    if begindate is not null then
      whrr := whrr || ' and mc.violation_date>=to_date(' || '''' ||
              begindate || '''' || ',' || '''' || 'yyyy/mm/dd' || '''' || ',' || '''' ||
              'nls_calendar=persian' || '''' || ')';
    else
      whrr := whrr || ' and trunc(mc.violation_date)=trunc(sysdate)';
    end if;
    if enddate is not null then
      whrr := whrr || ' and mc.violation_date<=to_date(' || '''' || enddate || '''' || ',' || '''' ||
              'yyyy/mm/dd' || '''' || ',' || '''' || 'nls_calendar=persian' || '''' || ')';
    
    end if;
  
    if cameracode is not null then
      whrr := whrr || ' and mc.camera_code =' || cameracode;
    end if;
  
    select y.id
      into comp_id
      from tbl_fps_company y
     where y.company_code = companycode;
    whrr := whrr || ' and  c.id =' || comp_id;
  
    open mm for  'select mc.plate_new,mc.camera_code,to_char(mc.violation_date,''yyyy/mm/dd hh24:mi:ss'',''nls_calendar=persian'')violation_date
   ,mc.violation_code,mc.violation_address,mc.speed,e.plate_image,e.confirm_image
  from tbl_fps_information_warning   mc,
       tbl_fps_info_image e,
       tbl_fps_info_log       l,
       tbl_fps_user           u,
       tbl_fps_company        c
 where mc.id=e.fk_info_warning_id
   and mc.status in(3,5)
   and  mc.id = l.fk_warning_id
   and l.fk_user_id= u.id
   and u.company_id = c.id' || whrr;
  end getall_infowar_bysend;

  -----------------edit_transfer_infowar                                
  procedure edit_transfer_infowar(mm        out sys_refcursor,
                                  infowarid number,
                                  ststus    number,
                                  userid    number,
                                  ip_       varchar2,
                                  actiocode number) is
    actid number;
  begin
    begin
      update tbl_fps_information_warning w
         set w.transfer_status = ststus
       where w.id = infowarid;
    
      select a.id
        into actid
        from tbl_fps_action_type a
       where a.action_code = actiocode;
       insert into tbl_fps_info_log
        values
          (seq_info_log.nextval,sysdate,400,null,null, ip_ , sysdate, actid, infowarid,userid );
    
      commit;
      open mm for
        select 1 res from dual;
    exception
      when others then
        open mm for
          select 0 res from dual;
    end;
  end edit_transfer_infowar;
  
  ------------------test
  procedure test (mm out sys_refcursor)is
    begin
      open mm for
      select 'fokaname' mm  from dual;
      end test;
      
       -----------------get_image_infowar2
  procedure get_image_infowar2(infowarid in number, plateimage out blob,vehicleimage1 out blob, vehicleimage2 out blob)is
    begin
      select e.plate_image,e.vehicle_image1,e.vehicle_image2 into plateimage,vehicleimage1,vehicleimage2 from tbl_fps_info_image e
      where e.fk_info_warning_id=infowarid;
      end get_image_infowar2;
      
      
end dbpk_smtcam;
/

