create package dbpk_smtcam is
  -------------------------------add_info_warning
  procedure add_info_warning(mm                  out sys_refcursor,
                             CameraCode          number,
                             Speed_              number,
                             PlateNo             varchar2,
                             ViolationOccureDate varchar2,
                             ViolationTypeCode   number,
                             viol_add            varchar2,
                             usercode            number,
                             plateimage          blob,
                             vehicleimage1       blob,
                             vehicleimage2       blob,
                             check_type            number,
                             surveillance_cam number,
                            user_ip number);

  --------------------get_top_infowarning
  procedure get_top_infowarning(mm          out sys_refcursor,
                                companyid number,
                                begindate   varchar2,
                                enddate     varchar2,
                                cameracode  number,
                                violcode    number);

  -----------------get_image_infowar
  procedure get_image_infowar(mm out sys_refcursor, infowarid number);

  ----------------edit_info_warning
  procedure edit_info_warning(mm         out sys_refcursor,
                              infowarid  number,
                              status     number,
                              userid     number,
                              plateno    varchar2,
                              ip_        varchar2,
                              contrad_id number,
                              actiocode  number);

  -----------------getall_CONTRADICTORINESS
  procedure getall_CONTRADICTORINESS(mm out sys_refcursor);

  ----------------getall_infowar_bysend
  procedure getall_infowar_bysend(mm          out sys_refcursor,
                                  begindate   varchar2,
                                  enddate     varchar2,
                                  companycode number,
                                  cameracode  number);

  -----------------edit_transfer_infowar
  procedure edit_transfer_infowar(mm        out sys_refcursor,
                                  infowarid number,
                                  ststus    number,
                                  userid    number,
                                  ip_       varchar2,
                                  actiocode number);


  ------------------test
  procedure test (mm out sys_refcursor);

   -----------------get_image_infowar2
  procedure get_image_infowar2(infowarid in number, plateimage out blob,vehicleimage1 out blob, vehicleimage2 out blob);
end dbpk_smtcam;
/

