create FUNCTION CONVHART_P(HRF IN varchar2) RETURN varchar2 IS
BEGIN
  IF HRF = '01' THEN ---ALF
    RETURN 'الف';
  ELSIF HRF = '02' THEN ---B
    RETURN 'ب';
  ELSIF HRF = '03' THEN ---T
    RETURN 'ت';
  ELSIF HRF = '04' THEN ---J
    RETURN 'ج';
  ELSIF HRF = '05' THEN ---D
    RETURN 'د';
  ELSIF HRF = '06' THEN ---C
    RETURN 'س';
  ELSIF HRF = '07' THEN ---S
    RETURN 'ص';
  ELSIF HRF = '08' THEN ---TA
        RETURN 'ط';
  ELSIF HRF = '09' THEN ---AYN
       RETURN 'ع';
  ELSIF HRF = '10' THEN ---GH
    RETURN 'ق';
  ELSIF HRF = '11' THEN ---L
    RETURN 'ل';
  ELSIF HRF = '12' THEN ---M
    RETURN 'م';
  ELSIF HRF = '13' THEN ---N
    RETURN 'ن';
  ELSIF HRF = '14' THEN  ----V
    RETURN 'و';
  ELSIF HRF = '15' THEN ----H
    RETURN 'ه';
  ELSIF HRF = '16' THEN ----Y
    RETURN 'ي';
  ELSIF HRF = '18' THEN  ----K
        RETURN 'ک';
    ELSIF HRF = '19' THEN ----ZH
    RETURN 'ژ';
  ELSIF HRF = '20' THEN ---P
       RETURN 'پ';
   ELSE
    RETURN '00000';
  END IF;
END;
/

