create procedure add_info_warning(mm                  out number,
                             CameraCode          number,
                             Speed_              number,
                             PlateNo             varchar2,
                             ViolationOccureDate varchar2,
                             ViolationTypeCode   number,
                             viol_add            varchar2,
                             usercode            number,
                             plateimage          blob,
                             vehicleimage1       blob,
                             vehicleimage2       blob,
                             check_type          number,
                             surveillance_cam    number,
                             user_ip             varchar2) is
    seq    number;
    userid number;

  begin
    begin
      select u.id
        into userid
        from tbl_fps_user u
       where u.user_code = usercode;
      select seq_information_warning.nextval into seq from dual;
      insert into tbl_fps_information_warning
      values
        (seq,
         sysdate,
         400,
         null,
         null,
         CameraCode,
         check_type,
         surveillance_cam,
         PlateNo,
         PlateNo,
         Speed_,
         1,
         0,
         viol_add,
         to_date(ViolationOccureDate,
                 'yyyy/mm/dd hh24:mi:ss',
                 'nls_calendar=persian'),
         null,
         ViolationTypeCode);

      insert into tbl_fps_info_log
      values
        (seq_info_log.nextval,
         sysdate,
         400,
         null,
         null,
         user_ip,
         sysdate,
         1,
         seq,
         userid);
      if check_type = 1 then

        insert into tbl_fps_info_image
        values
          (seq_image_info.nextval,
           sysdate,
           400,
           null,
           null,
           null,
           plateimage,
           vehicleimage1,
           vehicleimage2,
           seq);

      elsif check_type = 2 then
        insert into tbl_fps_info_image
        values
          (seq_image_info.nextval,
           sysdate,
           400,
           null,
           null,
           vehicleimage1,
           plateimage,
           null,
           null,
           seq);

      end if;
      commit;

    /*  select 1 into mm from dual;*/

      select 1 into mm from dual;

    exception
      when others then

        select 0 into mm from dual;
    end;

  end add_info_warning;
/

